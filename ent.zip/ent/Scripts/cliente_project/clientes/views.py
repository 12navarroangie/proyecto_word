
from django.shortcuts import render, redirect
from .models import Cliente
from .forms import ClienteForm


# Create your views here.

def lista_clientes(request):
    clientes = Cliente.objects.all()  # Obtener todos los clientes
    return render(request, 'lista_clientes.html', {'clientes': clientes})  

# Vista para crear un nuevo cliente
def nuevo_cliente(request):
    if request.method == 'POST':
        form = ClienteForm(request.POST)  # Crear un formulario con los datos del POST
        if form.is_valid():
            form.save()  # Guardar el nuevo cliente en la base de datos
            return redirect('lista_clientes')  # Redirigir a la lista de clientes
    else:
        form = ClienteForm()  # Crear un formulario vacío

    # Renderizar la plantilla con el formulario
    return render(request, 'nuevo_cliente.html', {'form': form})  #

# Vista para editar un cliente existente
def editar_cliente(request, id):
    cliente = Cliente.objects.get(id=id)  # Obtener el cliente por su ID
    if request.method == 'POST':
        # Crear un formulario con los datos del POST y el cliente existente
        form = ClienteForm(request.POST, instance=cliente)          
        if form.is_valid():
            form.save()  # Guardar los cambios en el cliente
            return redirect('lista_clientes')  # Redirigir a la lista de clientes
    else:
        form = ClienteForm(instance=cliente)#Crear un formulario con los datos del cliente
    return render(request, 'editar_cliente.html', {'form': form})  # 

# Vista para eliminar un cliente existente
def eliminar_cliente(request, id):
    cliente = Cliente.objects.get(id=id)  # Obtener el cliente por su ID
    if request.method == 'POST':
        cliente.delete()  # Eliminar el cliente de la base de datos
        return redirect('lista_clientes')  # Redirigir a la lista de clientes
    return render(request, 'eliminar_cliente.html', {'cliente': cliente})  # 


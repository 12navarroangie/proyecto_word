
from django.urls import path
from . import views

urlpatterns = [
    path('', views.lista_clientes, name='lista_clientes'),  # URL para listar clientes
    path('nuevo/', views.nuevo_cliente, name='nuevo_cliente'),  # URL para crear un nuevo cliente
    path('<int:id>/editar/', views.editar_cliente, name='editar_cliente'),  # URL para editar un cliente existente
    path('<int:id>/eliminar/', views.eliminar_cliente, name='eliminar_cliente'),  # URL para eliminar un cliente existente
]


